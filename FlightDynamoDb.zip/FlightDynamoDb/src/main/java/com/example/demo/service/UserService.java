package com.example.demo.service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;



import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.User;

import com.example.demo.repository.UserRepository;


@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	public void bookFlight(User user) {
		
		userRepository.bookFlight(user);
		
		
	}

//	public Mono<User> fetchUserDetailsByPnr(String pnr) {
//		// TODO Auto-generated method stub
//		
//		return userRepository.findById(pnr);
//	}
//
//	public Flux<User> fetchTicketsHistory(String emailId) throws EmailNotFoundException, InterruptedException {
//		// TODO Auto-generated method stub
//		
//		Flux<User> flux = userRepository.findByEmailId(emailId);
//		
//		System.out.println(flux.hasElements().subscribe());
//		
//		Mono<Boolean> m = flux.hasElements();
//		
//		System.out.println(m);
//		
////		m.subscribe(v ->{
////			System.out.println(v);
////		});
//		
//		m.subscribe(p -> h = p);
//		
////		m.handle((v,sink)->{
////			
////			if(v) {
////				h = v;
////				sink.next(flux);
////			}else {
////				sink.error(new EmailNotFoundException("Email ID Not Available"));
////			}
////			
////		}).subscribe();
//		
//		Thread.sleep(2000);
//		System.out.println(h);
//		if(!h) {
//			throw new  EmailNotFoundException("Email ID Not Available");
//		}
//
//		return flux;
//		
//		 //throw new EmailNotFoundException("Email ID Not Available");		
//			
//	}
//	
//	public void cancelTicketByPnr(String pnr) {
//		// TODO Auto-generated method stub
//	//	 userRepository.deleteById(pnr); 
//		 userRepository.deleteById(pnr);
//		 
//	}


}
