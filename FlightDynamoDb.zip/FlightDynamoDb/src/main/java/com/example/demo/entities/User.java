package com.example.demo.entities;

import java.util.List;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@DynamoDbBean
public class User {
	
	
	private String id;
	private String name;
	private String emailId;
	private int flightNumber;
	private int seats;
	private List<Passenger> passengersList;
	
	@DynamoDbPartitionKey
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@DynamoDbSortKey
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@DynamoDbAttribute(value = "emailId")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	@DynamoDbAttribute(value = "flightNumber")
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	
	@DynamoDbAttribute(value = "seats")
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	
	@DynamoDbAttribute(value = "passengersList")
	public List<Passenger> getPassengersList() {
		return passengersList;
	}
	public void setPassengersList(List<Passenger> passengersList) {
		this.passengersList = passengersList;
	}
	
	
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", emailId=" + emailId + ", flightNumber=" + flightNumber
				+ ", seats=" + seats + ", passengersList=" + passengersList + "]";
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(String id, String name, String emailId, int flightNumber, int seats,
			List<Passenger> passengersList) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.flightNumber = flightNumber;
		this.seats = seats;
		this.passengersList = passengersList;
	} 
	

}
