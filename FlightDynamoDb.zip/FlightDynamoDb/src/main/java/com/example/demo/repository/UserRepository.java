package com.example.demo.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.User;

import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;


@Repository
public class UserRepository{
	
	
	
    @Autowired
    private DynamoDbTable<User> userTable;
    
    
    public void bookFlight(User user) {

        try {

            // Put the data into a DynamoDB table
            userTable.putItem(user);
            
            System.out.println("user is saved");

        } catch (DynamoDbException e) {
            System.err.println(e.getMessage());
            System.exit(1);
            System.out.println("movie can not be saved");
        }
    }
	

}
