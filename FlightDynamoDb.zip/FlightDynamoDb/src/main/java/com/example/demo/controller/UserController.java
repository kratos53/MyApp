package com.example.demo.controller;

import java.util.List;
import java.util.Objects;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.User;

import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;


@RestController
@RequestMapping("/api/v1.0")
public class UserController {
	
	@Autowired
	private UserService userService;
	
		
	@PostMapping("/flight/booking")
	public void save(@RequestBody User user) {
		
		 userService.bookFlight(user);	
	}
	
//	@GetMapping("/flight/ticket/{pnr}")
//	public Mono<User> bookedTicketDetails(@PathVariable("pnr") String pnr) {
//		
//		Mono<User> user = userService.fetchUserDetailsByPnr(pnr);
//		return user;
//	}
//	
//	@GetMapping("/flight/tickets/{emailId}")
//	public Flux<User> ticketHistory(@PathVariable("emailId") String emailId) throws EmailNotFoundException, InterruptedException {
//		
//		Flux<User> user = userService.fetchTicketsHistory(emailId);
//		if(user.hasElements() != null)
//			return user;
//		else
//			throw new EmailNotFoundException("Email Not Available");
//	}
//	
//	@ExceptionHandler
//	public ResponseEntity<String> handle(EmailNotFoundException ex){
//		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
//		
//	}
//	
//	@DeleteMapping("/flight/cancel/{pnr}")
//	public Mono<String> cancelTicket(@PathVariable("pnr") String pnr) {
//		
//		System.out.println(pnr);
//		
//		userService.cancelTicketByPnr(pnr);
//		Mono<String> str = Mono.just("Flight cancelled sucessfully");
//		return str;
//		
//	}

}
