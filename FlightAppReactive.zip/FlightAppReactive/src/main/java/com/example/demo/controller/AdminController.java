package com.example.demo.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.AdminDto;
import com.example.demo.model.Admin;
import com.example.demo.service.AdminService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/v1.0")
public class AdminController {
	
	private Map<String,String> map = new HashMap<String,String>();
	
	@Autowired
	private AdminService adminService; 
	
	@PostMapping("/airlines")
	public Mono<AdminDto> saveAdmin(@RequestBody Mono<AdminDto> admin){
		System.out.println("111111111111111112222222222");
		return adminService.saveAdmin(admin);
	}
	
	@PutMapping("/admin/block/{id}")
	public String flightBlock(@PathVariable("id") int flightNumber) {
		
		adminService.flightBlock(flightNumber);
		return "Flight Status Changed Successfully";
		
	}
	
	@PutMapping("/admin/unblock/{id}")
	public String flightUnBlock(@PathVariable("id") int flightNumber) {
		
		adminService.flightUnBlock(flightNumber);
		return "Flight Status Changed Successfully";
		
	}
	
//	@PostMapping("/login")
//	public Map<String, String> login(@RequestBody AuthorizedUser user)
//	{
//		System.out.println(12);
//		try
//		{
//
//			String jwtToken = adminService.generateToken(user.getUsername(), user.getPassword());
//            map.put("message", "User successfully logged in");
//            map.put("token", jwtToken);
//            System.out.println(map);
//        }
//        catch(Exception e)
//        {
//            map.put("message", "User unsuccessful to login");
//            map.put("token", null);
//           
//        }
//		
//		System.out.println(map);
//		
//		return map;
//		
//	}
//	
	
	
	@GetMapping("/flight/search/{startDate}/{endDate}/{startTime}/{endTime}")
	public Flux<Admin> getFlightsByDateAndTime(@PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
			@PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime){
		
		String sDate = startDate.toString();
		String eDate = endDate.toString();
		Flux<Admin> resultFlights = adminService.searchFlights(sDate,eDate,startTime,endTime);
		return resultFlights;
		
	}
	
	@GetMapping("/flight/searchbyplaces/{start}/{destination}")
	public Flux<Admin> getFlightsByPlaces(@PathVariable("start") String start,@PathVariable("destination") String destination){
		
		Flux<Admin> resultFlights = adminService.searchFlightsByPlaces(start,destination);
		return resultFlights;
		
	}
}
