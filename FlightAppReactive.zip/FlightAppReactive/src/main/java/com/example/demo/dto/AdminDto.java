package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminDto {
	
	private int id;
	private String flightName;
	private double price;
	private boolean blocked;
	private String start;
	private String destination;
	private String startTime;
	private String arrivalTime;
	private String startDate;
	private String endDate;

}
