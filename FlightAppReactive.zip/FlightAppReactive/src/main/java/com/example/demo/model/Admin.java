package com.example.demo.model;

import javax.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Document(collection = "admin")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin {
	
	@Id
	private int id;
	private String flightName;
	private double price;
	private boolean blocked;
	private String start;
	private String destination;
	private String startTime;
	private String arrivalTime;
	private String startDate;
	private String endDate;

}
