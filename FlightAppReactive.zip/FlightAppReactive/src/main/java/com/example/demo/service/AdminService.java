package com.example.demo.service;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.AdminDto;
import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepository;
import com.example.demo.utils.AppUtils;

//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	
	public Mono<AdminDto> saveAdmin(Mono<AdminDto> admin){
		return admin.map(AppUtils::adminDtotoEntity)
		.flatMap(adminRepository::insert)
		.map(AppUtils::adminEntitytoDto);
	}

	public void flightBlock(int flightNumber) {
		
		Mono<Admin> a = adminRepository.findById(flightNumber);
		a.map(e-> {
			e.setId(flightNumber);
			e.setBlocked(true);
			return e;
		}).subscribe(s->{
			adminRepository.save(s).subscribe();
		});
		
		
	}

	public void flightUnBlock(int flightNumber) {
		
		Mono<Admin> a = adminRepository.findById(flightNumber);
		a.map(e-> {
			e.setId(flightNumber);
			e.setBlocked(false);
			return e;
		}).subscribe(s->{
			adminRepository.save(s).subscribe();
		});
		
	}

	public Flux<Admin> searchFlights(String sDate, String eDate, String startTime, String endTime) {
		
		return adminRepository.searchFlightsByDates(sDate, eDate, startTime, endTime);
	}

	public Flux<Admin> searchFlightsByPlaces(String start, String destination) {
		
		return adminRepository.searchFlightsByStartAndDestination(start, destination);
	}
	
//	public boolean validateUser(String username, String password) {
//        
//        System.out.println("Inside validate method Impl");
// 
//        
//        if(username.equals("admin") && password.equals("admin"))
//        {
//            return true;
//        }
//        else
//            return false;
//    }
//	
//	public String generateToken(String username, String password) throws Exception
//    {
//		String jwtToken ="";
//        
//        if(username==null || password == null)
//        {
//            System.out.println("No user or no password");
//            throw new Exception("Please provide valid credentials!");
//        }
//        
//        boolean flag = validateUser(username, password);
//        System.out.println(flag);
//        
//        if(!flag)
//        {
//            throw new Exception("Credentials are incorrect");
//            
//        }
//        else
//        {
//            jwtToken = Jwts.builder().setSubject(username).setIssuedAt(new Date())
//                    .setExpiration(new Date(System.currentTimeMillis()+ 300000))
//                    .signWith(SignatureAlgorithm.HS256,"secret key").compact();
//        }
//
//       return jwtToken;
//    }

}
