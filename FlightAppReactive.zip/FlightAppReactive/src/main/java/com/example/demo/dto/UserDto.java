package com.example.demo.dto;

import java.util.ArrayList;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import com.example.demo.model.Passenger;
import com.example.demo.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Data
//@AllArgsConstructor
//@NoArgsConstructor
@Document
public class UserDto {
	
	@Id
	private String id;
	private String name;
	private String emailId;
	private int flightNumber;
	private int seats;
	private ArrayList<Passenger> passengersList; 
	//private String pnr;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public ArrayList<Passenger> getPassengersList() {
		return passengersList;
	}
	public void setPassengersList(ArrayList<Passenger> passengersList) {
		this.passengersList = passengersList;
	}
//	public String getPnr() {
//		return pnr;
//	}
//	public void setPnr(String pnr) {
//		this.pnr = pnr;
//	}
	
	public UserDto(String id, String name, String emailId, int flightNumber, int seats,
			ArrayList<Passenger> passengersList, String pnr) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.flightNumber = flightNumber;
		this.seats = seats;
		this.passengersList = passengersList;
	//	this.pnr = pnr;
	}
	@Override
	public String toString() {
		return "UserDto [id=" + id + ", name=" + name + ", emailId=" + emailId + ", flightNumber=" + flightNumber
				+ ", seats=" + seats + ", passengersList=" + passengersList  + "]";
	}	
	
	public UserDto()
	{
		
	}
	


}