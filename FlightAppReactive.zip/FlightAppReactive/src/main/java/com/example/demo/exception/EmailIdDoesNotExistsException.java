package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;



@ResponseStatus(code=HttpStatus.CONFLICT, reason="Email ID does not exists !")
public class EmailIdDoesNotExistsException extends Exception {


}