package com.example.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.UserDto;
import com.example.demo.model.User;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface UserRepository extends ReactiveMongoRepository<UserDto, Integer>{

	
	Mono<User> findById(String pnr);

	Flux<User> findByEmailId(String emailId);

	void deleteById(String pnr);
	

}
