package com.example.demo.utils;

import org.springframework.beans.BeanUtils;

import com.example.demo.model.User;
import com.example.demo.dto.AdminDto;
import com.example.demo.dto.UserDto;
import com.example.demo.model.Admin;

public class AppUtils {
	
public static AdminDto adminEntitytoDto(Admin admin) {
		
		AdminDto adminDto = new AdminDto();
		BeanUtils.copyProperties(admin, adminDto);
		return adminDto;
		
	}
	
	public static Admin adminDtotoEntity(AdminDto adminDto) {
		
		Admin admin = new Admin();
		BeanUtils.copyProperties(adminDto, admin);
		return admin;
		
	}
	
	public static UserDto userEntitytoDto(User user) {
		
		UserDto userDto = new UserDto();
		BeanUtils.copyProperties(user, userDto);
		return userDto;
		
	}
	
	public static User userDtotoEntity(UserDto userDto) {
		
		User user = new User();
		BeanUtils.copyProperties(userDto, user);
		return user;
		
	}

}
