package com.example.demo.service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.AdminDto;
import com.example.demo.dto.UserDto;
import com.example.demo.exception.FlightDoesNotExistsException;
import com.example.demo.model.Admin;
import com.example.demo.model.User;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AdminRepository adminRepository;

	public Mono<UserDto> bookFlight(UserDto user) throws FlightDoesNotExistsException{
		
		List<Admin> flights = new ArrayList<>();
		System.out.println(11111);
				Flux<Admin> flux = adminRepository.findAll();
				Mono<Admin> ad = adminRepository.findById(14);
				System.out.println(ad);
				
		flux.collectList().subscribe(flights::addAll);
		System.out.println(22222);

	
			for(Admin flight : flights)
			{
				if(user.getFlightNumber()==flight.getId())
				{
					System.out.println(444444444);
					return userRepository.insert(user);
					
				}
					
			}
			System.out.println(333333);
			throw new FlightDoesNotExistsException();
			
	}

	public Mono<User> fetchUserDetailsByPnr(String pnr) {
		// TODO Auto-generated method stub
		
		return userRepository.findById(pnr);
	}

	public Flux<User> fetchTicketsHistory(String emailId) {
		// TODO Auto-generated method stub
		
		return userRepository.findByEmailId(emailId);
	}
	
	public void cancelTicketByPnr(String pnr) {
		// TODO Auto-generated method stub
		 userRepository.deleteById(pnr); 
		 
	}


}
