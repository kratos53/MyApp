package com.example.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Admin;

import reactor.core.publisher.Flux;

@Repository
public interface AdminRepository extends ReactiveMongoRepository<Admin, Integer>{
	
	@Query("{'startDate': ?0 , 'endDate': ?1 , 'startTime': ?2 , 'arrivalTime' : ?3 }")
	Flux<Admin> searchFlightsByDates(String sDate,String eDate,String sTime,String eTime);
	
	Flux<Admin> searchFlightsByStartAndDestination(String start,String destination);

}
