package com.example.demo.model;

import java.util.ArrayList;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import com.example.demo.model.Passenger;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Document(collection = "user")
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class User {
	
	@Id
	private String id;
	private String name;
	private String emailId;
	private int flightNumber;
	private int seats;
	private ArrayList<Passenger> passengersList; 
	//private String pnr;	

}
